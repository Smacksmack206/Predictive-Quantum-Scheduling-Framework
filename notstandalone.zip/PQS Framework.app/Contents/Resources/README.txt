PQS Framework - Quantum-ML Power Management System

REQUIREMENTS:
- macOS 15.0 or later
- Python 3.11 or later
- Dependencies listed in requirements.txt

FIRST TIME SETUP:
1. Open Terminal
2. Run: pip3 install -r "/Applications/PQS Framework.app/Contents/Resources/requirements.txt"
3. Launch the app from Applications

The app will work on both Intel and Apple Silicon Macs.
